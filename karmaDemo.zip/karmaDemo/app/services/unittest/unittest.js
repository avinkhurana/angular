(function() {
  'use strict';

  angular.module('api.numModule', [])
  .factory('num', function() {
    var myNum = 8;
    return myNum;
  });
})();
