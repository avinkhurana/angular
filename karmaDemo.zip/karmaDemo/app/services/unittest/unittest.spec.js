describe('num factory', function() {
	
var myNum=4;

	
beforeEach(angular.mock.module('api.numModule'));

	
beforeEach(inject(function(_num_) {
		
num = _num_;
	}));


it('To check given number exists', function() {
		
	expect(num).toBeDefined();
	
});

	
it('To check given number not defined', function() {

	expect(num).not.toBeDefined();
	
});

	
/* Checking the dummy values if my addition giving expected values with Karma test*/  
	
describe('num factory', function() {
	  
it('The Number I am testing', function() {
		
// Checking with value in myNum at line 2
		
	expect(2 + 2).toEqual(4);
	  
});
	  
it(' I am checking my HelloWorld', function() {
		
// An intentionally failing test. No code within expect() will never equal 4.
		
	expect(2 + 2).toEqual(7);
	  
});
	
});

});
