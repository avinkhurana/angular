
var app = angular.module("target", []);
app.controller("wlcCtrl", function($scope) {
  $scope.wlcFun = function () {
     $scope.ad3 = $scope.ad1+$scope.ad2;
  } 
  
});