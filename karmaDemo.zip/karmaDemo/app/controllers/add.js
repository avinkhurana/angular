
var app = angular.module("target", []);
app.controller("helloCtrl", function($scope) {
  $scope.name = "";
  $scope.helloFun = function () {
     $scope.ad3 = $scope.ad1+$scope.ad2;
  } 
  
});